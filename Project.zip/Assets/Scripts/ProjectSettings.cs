public static class ProjectSettings
{
    public static float s_pedestrianSpeed = .025f;
    public static float s_roadLine = 1;
}
