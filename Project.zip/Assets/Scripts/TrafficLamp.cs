using UnityEngine;

[RequireComponent(typeof(MeshRenderer))]
public class TrafficLamp : MonoBehaviour
{
    [SerializeField] public bool isGreen;

    [SerializeField] private Material _enableMaterial;
    [SerializeField] private Material _disableMaterial;
    [SerializeField] private bool _active;

    private MeshRenderer _meshRenderer;

    private void Awake()
    {
        _meshRenderer = GetComponent<MeshRenderer>();
    }

    public void ChangeActive()
    {
        _active = !_active;
        _meshRenderer.material = _active ? _enableMaterial : _disableMaterial;
    }
}
