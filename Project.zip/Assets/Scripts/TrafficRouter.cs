using System.Collections;
using UnityEngine;

public class TrafficRouter : MonoBehaviour
{
    [SerializeField] private TrafficLamp[] _lamps;
    [SerializeField] private float[] _transitions;
    private PedestrianMovement[] _pedestrians;

    private int _activeLampId;

    private void Start()
    {
        _pedestrians = FindObjectsOfType<PedestrianMovement>();
        StartCoroutine(Tact());
    }

    private void EnumerationPedestrians(bool canMoveValue) 
    {
        foreach (PedestrianMovement p in _pedestrians)
        {
            p.SetMove(canMoveValue);
        }
    }

    private void ChangeEnabledLamp()
    {
        _lamps[_activeLampId].ChangeActive();
        _activeLampId = (_activeLampId + 1) % _lamps.Length;
        _lamps[_activeLampId].ChangeActive();
        if (_lamps[_activeLampId].isGreen)
        {
            EnumerationPedestrians(true);
        }
        else
        {
            EnumerationPedestrians(false);
        }
    }

    private IEnumerator Tact() 
    {
        foreach(float t in _transitions) 
        {
            yield return new WaitForSeconds(t);
            ChangeEnabledLamp();
        }
        StartCoroutine(Tact());
    }
}
