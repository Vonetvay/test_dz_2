using UnityEngine;

public class PedestrianMovement : MonoBehaviour
{
    private bool canMove;

    public void SetMove(bool value) 
    {
        canMove = value;
    }

    private void FixedUpdate()
    {
        if (canMove || ProjectSettings.s_roadLine <= transform.position.z)
        {
            transform.Translate(new Vector3(0f, 0f, ProjectSettings.s_pedestrianSpeed));
        }
    }
}
